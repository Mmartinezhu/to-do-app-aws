import { DynamoDBClient, QueryCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});
const TABLE_NAME = "ToDoTable";
const INDEX_NAME = "statusIndex";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));

  try {
    const qs = event.queryStringParameters || {};
    const mqs = event.multiValueQueryStringParameters || {};
    let status = qs.status;

    if (!status && Array.isArray(mqs.status) && mqs.status.length > 0) {
      status = mqs.status[0];
    }

    let userId = qs.userId;
    if (!userId && Array.isArray(mqs.userId) && mqs.userId.length > 0) {
      userId = mqs.userId[0];
    }

    if (!status) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: "Missing status (pending|done)" })
      };
    }

    // 👇👇 AQUÍ ESTABA EL PROBLEMA: usamos alias #st en vez de status directo
    const params = {
      TableName: TABLE_NAME,
      IndexName: INDEX_NAME,
      KeyConditionExpression: "#st = :s",
      ExpressionAttributeNames: {
        "#st": "status"
      },
      ExpressionAttributeValues: {
        ":s": { S: status }
      }
    };

    if (userId) {
      params.FilterExpression = "userId = :u";
      params.ExpressionAttributeValues[":u"] = { S: userId };
    }

    const data = await client.send(new QueryCommand(params));

    const items = data.Items || [];
    const tasks = items.map((item) => ({
      userId: item.userId.S,
      taskId: item.taskId.S,
      description: item.description.S,
      status: item.status.S,
      createdAt: item.createdAt?.S
    }));

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify(tasks)
    };
  } catch (error) {
    console.error("Error querying by status:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};