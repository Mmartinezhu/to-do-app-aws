import { DynamoDBClient, QueryCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});
const SEARCH_TABLE = "ToDoTableSearchIndex";

function extractQueryTerm(q) {
  const raw = q.toLowerCase();
  const cleaned = raw.replace(/[^a-z0-9áéíóúñüñ]+/gi, " ");
  const tokens = cleaned
    .split(/\s+/)
    .map((t) => t.trim())
    .filter((t) => t.length >= 3);

  return tokens[0] || null;
}

// Headers CORS reutilizables
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*", // o "http://localhost:3000"
  "Access-Control-Allow-Headers":
    "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
};

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event));

  const qs = event.queryStringParameters || {};
  const q = (qs.q || "").trim();
  const userId = (qs.userId || "").trim();

  if (!q || !userId) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Faltan parámetros 'q' o 'userId'" }),
    };
  }

  const term = extractQueryTerm(q);
  if (!term) {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify([]),
    };
  }

  const params = {
    TableName: SEARCH_TABLE,
    KeyConditionExpression: "term = :t",
    FilterExpression: "userId = :u",
    ExpressionAttributeValues: {
      ":t": { S: term },
      ":u": { S: userId },
    },
  };

  console.log("Query params:", JSON.stringify(params));

  const result = await client.send(new QueryCommand(params));

  const items =
    (result.Items || []).map((it) => ({
      userId: it.userId.S,
      taskId: it.taskId.S,
      description: it.description?.S,
      status: it.status?.S,
    })) || [];

  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify(items),
  };
};
