import { unmarshall } from "@aws-sdk/util-dynamodb";

export const handler = async (event) => {
  console.log("Raw event:", JSON.stringify(event));

  const records = event.Records || [];
  console.log("Records received:", records.length);

  for (const record of records) {
    const eventName = record.eventName; // INSERT | MODIFY | REMOVE
    const keys = unmarshall(record.dynamodb.Keys);

    const newImage = record.dynamodb.NewImage
      ? unmarshall(record.dynamodb.NewImage)
      : null;

    const oldImage = record.dynamodb.OldImage
      ? unmarshall(record.dynamodb.OldImage)
      : null;

    console.log("Event:", eventName, "Keys:", keys);

    if (eventName === "INSERT") {
      console.log("New item:", newImage);
    }

    if (eventName === "MODIFY") {
      console.log("Item modificado. Antes:", oldImage, "Después:", newImage);
    }

    if (eventName === "REMOVE") {
      console.log("Item eliminado:", oldImage);
    }
  }

  return { statusCode: 200 };
};