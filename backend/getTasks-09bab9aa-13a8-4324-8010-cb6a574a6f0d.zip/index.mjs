import { DynamoDBClient, QueryCommand } from "@aws-sdk/client-dynamodb";
const client = new DynamoDBClient({});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  try {
    const userId = event.queryStringParameters?.userId;

    if (!userId) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: "Missing userId" })
      };
    }

    const command = new QueryCommand({
      TableName: "ToDoTable",
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": { S: userId } }
    });

    const data = await client.send(command);

    const tasks = data.Items.map(item => ({
      taskId: item.taskId.S,
      description: item.description.S,
      status: item.status.S,
      createdAt: item.createdAt.S
    }));

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify(tasks)
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};
