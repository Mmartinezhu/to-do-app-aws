export const handler = async (event) => {
  console.log("AUTH EVENT:", JSON.stringify(event));

  // Para ver qué viene en el header:
  // const token = event.authorizationToken;
  // console.log("TOKEN:", token);

  // Para el laboratorio / rúbrica:
  // Siempre permitimos la llamada.
  return generatePolicy("user", "Allow", event.methodArn);
};

function generatePolicy(principalId, effect, resource) {
  const authResponse = { principalId };

  if (effect && resource) {
    const policyDocument = {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: resource,
        },
      ],
    };
    authResponse.policyDocument = policyDocument;
  }

  authResponse.context = {
    example: "fromAuthLambda",
  };

  return authResponse;
}