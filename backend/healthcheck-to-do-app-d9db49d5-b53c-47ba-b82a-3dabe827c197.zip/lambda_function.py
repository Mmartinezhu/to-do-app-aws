import urllib.request
import time

URL = "http://front-to-do-app-aws-47321758016375891.s3-website-us-east-1.amazonaws.com"

def lambda_handler(event, context):
    start = time.time()
    try:
        with urllib.request.urlopen(URL, timeout=5) as response:
            status_code = response.getcode()
            elapsed_ms = int((time.time() - start) * 1000)
            print(f"HEALTHCHECK OK status={status_code} latency_ms={elapsed_ms}")
            return {
                "statusCode": 200,
                "body": f"OK {status_code} in {elapsed_ms}ms"
            }
    except Exception as e:
        elapsed_ms = int((time.time() - start) * 1000)
        # IMPORTANTE: logueamos claramente ERROR para poder filtrarlo
        print(f"HEALTHCHECK ERROR latency_ms={elapsed_ms} error={e}")
        return {
            "statusCode": 500,
            "body": f"ERROR in {elapsed_ms}ms: {e}"
        }