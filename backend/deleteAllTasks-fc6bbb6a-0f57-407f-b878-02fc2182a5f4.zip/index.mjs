import { DynamoDBClient, QueryCommand, BatchWriteItemCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});

const TABLE_NAME = "ToDoTable";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));

  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const { userId } = body || {};

    if (!userId) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: "Missing userId" })
      };
    }

    let lastKey = undefined;
    let totalDeleted = 0;

    do {
      const queryCmd = new QueryCommand({
        TableName: TABLE_NAME,
        KeyConditionExpression: "userId = :u",
        ExpressionAttributeValues: {
          ":u": { S: userId }
        },
        ExclusiveStartKey: lastKey
      });

      const data = await client.send(queryCmd);
      const items = data.Items || [];

      if (items.length === 0 && !lastKey) {
        // no había tareas
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ message: "No hay tareas para borrar", deleted: 0 })
        };
      }

      // borrar en lotes de 25 (límite de BatchWriteItem)
      for (let i = 0; i < items.length; i += 25) {
        const batch = items.slice(i, i + 25);

        const requestItems = {
          [TABLE_NAME]: batch.map((item) => ({
            DeleteRequest: {
              Key: {
                userId: { S: item.userId.S },
                taskId: { S: item.taskId.S }
              }
            }
          }))
        };

        const batchCmd = new BatchWriteItemCommand({
          RequestItems: requestItems
        });

        await client.send(batchCmd);
        totalDeleted += batch.length;
      }

      lastKey = data.LastEvaluatedKey;
    } while (lastKey);

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        message: "Todas las tareas borradas para el usuario",
        userId,
        deleted: totalDeleted
      })
    };
  } catch (error) {
    console.error("Error deleting all tasks:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};