import { DynamoDBClient, UpdateItemCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));

  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const { userId, taskId, description, status } = body || {};

    if (!userId || !taskId) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: "Missing userId or taskId" })
      };
    }

    const updateParts = [];
    const exprValues = {};
    const exprNames = {};

    if (typeof description === "string") {
      updateParts.push("description = :d");
      exprValues[":d"] = { S: description };
    }

    if (typeof status === "string") {
      // usamos alias porque "status" es palabra reservada
      updateParts.push("#st = :s");
      exprValues[":s"] = { S: status };
      exprNames["#st"] = "status";
    }

    if (updateParts.length === 0) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: "No fields to update" })
      };
    }

    const command = new UpdateItemCommand({
      TableName: "ToDoTable",
      Key: {
        userId: { S: userId },
        taskId: { S: taskId }
      },
      UpdateExpression: "SET " + updateParts.join(", "),
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames: Object.keys(exprNames).length ? exprNames : undefined,
      ReturnValues: "UPDATED_NEW"
    });

    const data = await client.send(command);

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        message: "Task updated",
        attributes: data.Attributes
      })
    };
  } catch (error) {
    console.error("Error updating task:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};
