import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { userId, taskId, description, status } = body;

    if (!userId || !taskId || !description) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "Missing fields" }) };
    }

    const command = new PutItemCommand({
      TableName: "ToDoTable",
      Item: {
        userId: { S: userId },
        taskId: { S: taskId },
        description: { S: description },
        status: { S: status || "pending" },
        createdAt: { S: new Date().toISOString() }
      }
    });

    await client.send(command);

    return {
      statusCode: 201,
      headers: cors,
      body: JSON.stringify({ message: "Task created successfully" })
    };
  } catch (error) {
    console.error("Error creating task:", error);
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: "Internal server error" }) };
  }
};
