import { DynamoDBClient, BatchWriteItemCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";

const client = new DynamoDBClient({});
const SEARCH_TABLE = "ToDoTableSearchIndex";

// Extrae palabras de description + status
function extractTermsFromItem(item) {
  const textParts = [];

  if (item.description) textParts.push(item.description);
  if (item.status) textParts.push(item.status);

  const raw = textParts.join(" ").toLowerCase();

  // Reemplaza todo lo que no sea letra/número por espacio
  const cleaned = raw.replace(/[^a-z0-9áéíóúñüñ]+/gi, " ");

  const tokens = cleaned
    .split(/\s+/)
    .map((t) => t.trim())
    .filter((t) => t.length >= 3); // quitamos palabras muy cortas

  // Quitamos duplicados
  return Array.from(new Set(tokens));
}

export const handler = async (event) => {
  console.log("Raw event:", JSON.stringify(event));

  const records = event.Records || [];
  console.log("Registros recibidos:", records.length);

  for (const record of records) {
    const eventName = record.eventName; // INSERT | MODIFY | REMOVE

    const keys = unmarshall(record.dynamodb.Keys);
    const { userId, taskId } = keys;
    const taskKey = `${userId}#${taskId}`;

    const newImage = record.dynamodb.NewImage
      ? unmarshall(record.dynamodb.NewImage)
      : null;

    const oldImage = record.dynamodb.OldImage
      ? unmarshall(record.dynamodb.OldImage)
      : null;

    console.log("Evento:", eventName, "taskKey:", taskKey);

    const newTerms = newImage ? extractTermsFromItem(newImage) : [];
    const oldTerms = oldImage ? extractTermsFromItem(oldImage) : [];

    const writeRequests = [];

    if (eventName === "INSERT") {
      for (const term of newTerms) {
        writeRequests.push({
          PutRequest: {
            Item: {
              term:       { S: term },
              taskKey:    { S: taskKey },
              userId:     { S: userId },
              taskId:     { S: taskId },
              description:{ S: newImage.description || "" },
              status:     { S: newImage.status || "" },
            },
          },
        });
      }
    } else if (eventName === "MODIFY") {
      const newSet = new Set(newTerms);
  const oldSet = new Set(oldTerms);

  // Para TODAS las palabras actuales → sobreescribimos (upsert) el índice
  for (const term of newSet) {
    writeRequests.push({
      PutRequest: {
        Item: {
          term:       { S: term },
          taskKey:    { S: taskKey },
          userId:     { S: userId },
          taskId:     { S: taskId },
          description:{ S: newImage.description || "" },
          status:     { S: newImage.status || "" },
        },
      },
    });
  }

  // Palabras que existían antes y ya no están → DELETE
  for (const term of oldSet) {
    if (!newSet.has(term)) {
      writeRequests.push({
        DeleteRequest: {
          Key: {
            term:    { S: term },
            taskKey: { S: taskKey },
          },
        },
      });
    }
      }
    } else if (eventName === "REMOVE") {
      for (const term of oldTerms) {
        writeRequests.push({
          DeleteRequest: {
            Key: {
              term:    { S: term },
              taskKey: { S: taskKey },
            },
          },
        });
      }
    }

    if (writeRequests.length === 0) {
      console.log("Nada que escribir para este registro");
      continue;
    }

    // Enviamos en lotes de máximo 25 (para este caso, seguro sobra)
    while (writeRequests.length > 0) {
      const batch = writeRequests.splice(0, 25);

      const params = {
        RequestItems: {
          [SEARCH_TABLE]: batch,
        },
      };

      console.log("BatchWriteItem params:", JSON.stringify(params));

      const res = await client.send(new BatchWriteItemCommand(params));

      if (
        res.UnprocessedItems &&
        Object.keys(res.UnprocessedItems).length > 0
      ) {
        console.warn(
          "UnprocessedItems:",
          JSON.stringify(res.UnprocessedItems),
        );
      }
    }
  }

  return { statusCode: 200 };
};
