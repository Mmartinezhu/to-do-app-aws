import { DynamoDBClient, DeleteItemCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

export const handler = async (event) => {
  try {
    const { userId, taskId } = JSON.parse(event.body);

    if (!userId || !taskId) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "Missing userId or taskId" }) };
    }

    const command = new DeleteItemCommand({
      TableName: "ToDoTable",
      Key: {
        userId: { S: userId },
        taskId: { S: taskId }
      }
    });

    await client.send(command);

    return { statusCode: 200, headers: cors, body: JSON.stringify({ message: "Task deleted successfully" }) };
  } catch (error) {
    console.error("Error deleting task:", error);
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: "Internal server error" }) };
  }
};
